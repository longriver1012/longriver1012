class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { screenUV, color, attribute, Fn, storage, instanceIndex, If, uniform, vec4, objectWorldMatrix } = TSL
    // background

    const bgColor = screenUV.y.mix(color(0x9f87f7), color(0xf2cdcd));
    const bgVignette = screenUV.distance(.5).remapClamp(0.3, .8).oneMinus();
    const bgIntensity = 4;

    core.render.scene.backgroundNode = bgColor.mul(bgVignette.mul(color(0xa78ff6).mul(bgIntensity)));

    // create jelly effect material

    const pointerPosition = uniform(vec4(0));
    const elasticity = uniform(.4); // elasticity ( how "strong" the spring is )
    const damping = uniform(.94); // damping factor ( energy loss )
    const brushSize = uniform(.25);
    const brushStrength = uniform(.22);

    const jelly = Fn(({ renderer, geometry, object }) => {

      const count = geometry.attributes.position.count;

      // Create storage buffer attribute for modified position.

      const positionBaseAttribute = geometry.attributes.position;
      const positionStorageBufferAttribute = new THREE.StorageBufferAttribute(count, 3);
      const speedBufferAttribute = new THREE.StorageBufferAttribute(count, 3);

      geometry.setAttribute('storagePosition', positionStorageBufferAttribute);

      // Attributes

      const positionAttribute = storage(positionBaseAttribute, 'vec3', count);
      const positionStorageAttribute = storage(positionStorageBufferAttribute, 'vec3', count);

      const speedAttribute = storage(speedBufferAttribute, 'vec3', count);

      // Vectors

      // Base vec3 position of the mesh vertices.
      const basePosition = positionAttribute.element(instanceIndex);
      // Mesh vertices after compute modification.
      const currentPosition = positionStorageAttribute.element(instanceIndex);
      // Speed of each mesh vertex.
      const currentSpeed = speedAttribute.element(instanceIndex);

      //

      const computeInit = Fn(() => {

        // Modified storage position starts out the same as the base position.

        currentPosition.assign(basePosition);

      })().compute(count);

      //

      const computeUpdate = Fn(() => {

        // pinch

        If(pointerPosition.w.equal(1), () => {

          const worldPosition = objectWorldMatrix(object).mul(currentPosition);

          const dist = worldPosition.distance(pointerPosition.xyz);
          const direction = pointerPosition.xyz.sub(worldPosition).normalize();

          const power = brushSize.sub(dist).max(0).mul(brushStrength);

          currentPosition.addAssign(direction.mul(power));

        });

        // compute ( jelly )

        const distance = basePosition.distance(currentPosition);
        const force = elasticity.mul(distance).mul(basePosition.sub(currentPosition));

        currentSpeed.addAssign(force);
        currentSpeed.mulAssign(damping);

        currentPosition.addAssign(currentSpeed);

      })().compute(count).setName('Update Jelly');

      // initialize the storage buffer with the base position

      computeUpdate.onInit(() => renderer.compute(computeInit));

      //

      return computeUpdate;

    });

    const material = new THREE.MeshNormalNodeMaterial();
    material.geometryNode = jelly();
    material.positionNode = attribute('storagePosition');

    this.object.children[0].material = material

    const gui = core.render.renderer.inspector.createParameters('Settings');
    gui.add(elasticity, 'value', 0, .5).name('elasticity');
    gui.add(damping, 'value', .9, .98).name('damping');
    gui.add(brushSize, 'value', .1, .5).name('brush size');
    gui.add(brushStrength, 'value', .1, .3).name('brush strength');

    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();
    this.pointerPosition = pointerPosition

    window.addEventListener('pointermove', this._onPointerMove);
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {

  }

  _onPointerMove = (event) => {
    this.pointer.set((event.clientX / window.innerWidth) * 2 - 1, - (event.clientY / window.innerHeight) * 2 + 1);

    this.raycaster.setFromCamera(this.pointer, this.core.render.camera);

    const intersects = this.raycaster.intersectObject(this.core.render.scene);

    if (intersects.length > 0) {

      const intersect = intersects[0];

      this.pointerPosition.value.copy(intersect.point);
      this.pointerPosition.value.w = 1; // enable

    } else {

      this.pointerPosition.value.w = 0; // disable

    }
  }
}