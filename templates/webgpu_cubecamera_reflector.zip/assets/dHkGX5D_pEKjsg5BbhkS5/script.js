class Script extends VD.Component {
  /**
   * @serialize
   * @type {THREE.Texture}
   * @label Some Object
   */
  hdr = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    this.object.traverse(item => {
      if (item instanceof THREE.Mesh) {
        item.material.envMap = this.hdr
      }
    })
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {
    
  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {

  }
}