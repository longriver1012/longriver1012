class Script extends VD.Component {
  /**
   * @serialize
   * @type {THREE.Object3D} 
   * @label sourceModel
   */
  sourceModel = null;

  /**
   * @serialize
   * @type {THREE.Object3D} 
   * @label targetModel
   */
  targetModel = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    this.targetModel.position.y = 1;
    this.source = this.getSource(this.sourceModel);
    this.mixer = this.retargetModel(this.source, this.targetModel);
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    const delta = core.timer.getDelta()

    this.source.mixer.update(delta);
    this.mixer.update(delta);
  }

  getSource(sourceModel) {

    const clip = sourceModel.animations[0];

    const helper = new THREE.SkeletonHelper(sourceModel);
    const skeleton = new THREE.Skeleton(helper.bones);

    const mixer = new THREE.AnimationMixer(sourceModel);
    mixer.clipAction(sourceModel.animations[0]).play();

    return { clip, skeleton, mixer };

  }

  retargetModel(sourceModel, targetModel) {

    const targetSkin = targetModel.children[0].children[1];

    const retargetOptions = {

      // specify the name of the source's hip bone.
      hip: 'mixamorigHips',

      // preserve the scale of the target model
      scale: .01,

      // use ( 0, 1, 0 ) to ignore xz hip movement.
      //hipInfluence: new THREE.Vector3( 0, 1, 0 ),

      // Map of target's bone names to source's bone names -> { targetBoneName: sourceBoneName }
      getBoneName: function (bone) {

        return 'mixamorig' + bone.name;

      }

    };

    const retargetedClip = ADDONS.SkeletonUtils.retargetClip(targetSkin, sourceModel.skeleton, sourceModel.clip, retargetOptions);

    const mixer = new THREE.AnimationMixer(targetSkin);
    mixer.clipAction(retargetedClip).play();

    return mixer;

  }

}