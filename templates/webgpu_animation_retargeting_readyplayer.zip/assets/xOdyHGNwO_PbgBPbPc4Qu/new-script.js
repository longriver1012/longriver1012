class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { reflector } = TSL
    // floor
    const reflection = reflector();
    reflection.target.rotateX(- Math.PI / 2);
    core.render.scene.add(reflection.target);

    const floorMaterial = new THREE.NodeMaterial();
    floorMaterial.colorNode = reflection;
    floorMaterial.opacity = .2;
    floorMaterial.transparent = true;

    const floor = new THREE.Mesh(new THREE.BoxGeometry(50, .001, 50), floorMaterial);
    floor.receiveShadow = true;

    floor.position.set(0, 0, 0);
    core.render.scene.add(floor);
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }
}