class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { screenUV, color, vec2 } = TSL

    const horizontalEffect = screenUV.x.mix(color(0x13172b), color(0x311649));
    const lightEffect = screenUV.distance(vec2(0.5, 1.0)).oneMinus().mul(color(0x0c5d68));

    core.render.scene.backgroundNode = horizontalEffect.add(lightEffect);
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }
}