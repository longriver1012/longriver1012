class Script extends VD.Component {
  /**
   * @serialize
   * @type {THREE.Texture} 
   * @label causticMap
   */
  causticMap = null;

  /**
   * @serialize
   * @type {THREE.Texture} 
   */
  colors = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const duck = this.object.children[0];
    duck.material = new THREE.MeshPhysicalNodeMaterial();
    duck.material.side = THREE.DoubleSide;
    duck.material.transparent = true;
    duck.material.color = new THREE.Color(0xFFD700);
    duck.material.transmission = 1;
    duck.material.thickness = .25;
    duck.material.ior = 1.5;
    duck.material.metalness = 0;
    duck.material.roughness = .1;
    duck.castShadow = true;

    const { uniform, Fn, positionLocal, refract, positionViewDirection, normalView, div, vec2, vec3, vec4, texture } = TSL

    const causticOcclusion = uniform(20);

    duck.material.castShadowPositionNode = Fn(() => {

      // optional: add some distortion to the geometry shadow position if needed

      return positionLocal;

    })();

    duck.material.castShadowNode = Fn(() => {

      const refractionVector = refract(positionViewDirection.negate(), normalView, div(1.0, duck.material.ior)).normalize();
      const viewZ = normalView.z.pow(causticOcclusion);

      const textureUV = refractionVector.xy.mul(.6);

      const causticColor = uniform(duck.material.color);
      const chromaticAberrationOffset = normalView.z.pow(- .9).mul(.004);

      const causticProjection = vec3(
        texture(this.causticMap, textureUV.add(vec2(chromaticAberrationOffset.negate(), 0))).r,
        texture(this.causticMap, textureUV.add(vec2(0, chromaticAberrationOffset.negate()))).g,
        texture(this.causticMap, textureUV.add(vec2(chromaticAberrationOffset, chromaticAberrationOffset))).b
      );

      return causticProjection.mul(viewZ.mul(25)).add(viewZ).mul(causticColor);

    })();

    core.render.renderer.shadowMap.transmitted = true;

    const glassMaterial = new THREE.MeshPhysicalNodeMaterial();
    glassMaterial.map = this.colors;
    glassMaterial.side = THREE.DoubleSide;
    glassMaterial.transparent = true;
    glassMaterial.color = new THREE.Color(0xffffff);
    glassMaterial.transmission = 1;
    glassMaterial.ior = 1.5;
    glassMaterial.metalness = 0;
    glassMaterial.roughness = .1;
    glassMaterial.castShadowNode = vec4(texture(this.colors).rgb, .8);

    const glass = new THREE.Mesh(new THREE.PlaneGeometry(.2, .2), glassMaterial);
    glass.position.y = .1;
    glass.castShadow = true;
    glass.visible = false;
    core.render.scene.add(glass);

    const gui = core.render.renderer.inspector.createParameters('Settings');
    gui.add(causticOcclusion, 'value', 0, 20).name('caustic occlusion');
    gui.addColor(duck.material, 'color').name('material color');
    gui.add({ model: 'duck' }, 'model', [
      'duck',
      'glass'
    ]).onChange(model => {

      duck.visible = glass.visible = false;

      if (model === 'duck') {

        duck.visible = true;

      } else if (model === 'glass') {

        glass.visible = true;

      }

    });

    this.duck = duck
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    this.duck.rotation.y -= 0.01
  }
}