class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    this.object.shadow.intensity = .95;
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {
    
  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }
}