class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { viewportLinearDepth, linearDepth, hashBlur, viewportSharedTexture, color, checker, modelScale, uv, screenUV } = TSL
    // compare depth from viewportLinearDepth with linearDepth() to create a distance field
    // viewportLinearDepth return the linear depth of the scene
    // linearDepth() returns the linear depth of the mesh
    const depthDistance = viewportLinearDepth.distance(linearDepth());

    const depthAlphaNode = depthDistance.oneMinus().smoothstep(.90, 2).mul(10).saturate();
    const depthBlurred = hashBlur(viewportSharedTexture(), depthDistance.smoothstep(0, .6).mul(40).clamp().mul(.1));

    const blurredBlur = new THREE.MeshBasicNodeMaterial();
    blurredBlur.backdropNode = depthBlurred.add(depthAlphaNode.mix(color(0x003399).mul(.3), 0));
    blurredBlur.transparent = true;
    blurredBlur.side = THREE.DoubleSide;

    const depthMaterial = new THREE.MeshBasicNodeMaterial();
    depthMaterial.backdropNode = depthAlphaNode;
    depthMaterial.transparent = true;
    depthMaterial.side = THREE.DoubleSide;

    const checkerMaterial = new THREE.MeshBasicNodeMaterial();
    checkerMaterial.backdropNode = hashBlur(viewportSharedTexture(), .05);
    checkerMaterial.backdropAlphaNode = checker(uv().mul(3).mul(modelScale.xy));
    checkerMaterial.opacityNode = checkerMaterial.backdropAlphaNode;
    checkerMaterial.transparent = true;
    checkerMaterial.side = THREE.DoubleSide;

    const pixelMaterial = new THREE.MeshBasicNodeMaterial();
    pixelMaterial.backdropNode = viewportSharedTexture(screenUV.mul(100).floor().div(100));
    pixelMaterial.transparent = true;

    // box / floor

    const box = new THREE.Mesh(new THREE.BoxGeometry(2, 2, 2), blurredBlur);
    box.position.set(0, 1, 0);
    box.renderOrder = 1;
    core.render.scene.add(box);

    const materials = {
      'blurred': blurredBlur,
      'depth': depthMaterial,
      'checker': checkerMaterial,
      'pixel': pixelMaterial
    };

    const options = { material: 'blurred' };
    box.material = materials[options.material];

    const gui = core.render.renderer.inspector.createParameters('Scene settings');
    gui.add(box.scale, 'x', 0.1, 2, 0.01).name('box scale x');
    gui.add(box.scale, 'y', 0.1, 2, 0.01).name('box scale y');
    gui.add(options, 'material', Object.keys(materials)).onChange(name => {
      box.material = materials[name];
    });
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }
}