class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { positionWorld } = TSL

    const floor = new THREE.Mesh(new THREE.BoxGeometry(5, .01, 5), new THREE.MeshBasicNodeMaterial({
      color: 0xff6600,
      opacityNode: positionWorld.xz.distance(0).oneMinus().clamp(),
      transparent: true,
      depthWrite: false
    }));
    floor.position.set(0, 0, 0);
    core.render.scene.add(floor);
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }
}