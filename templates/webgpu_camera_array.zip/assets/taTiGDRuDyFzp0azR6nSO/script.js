const AMOUNT = 6;

class Script extends VD.Component {
  /**
   * @serialize
   * @type {THREE.Object3D} 
   * @label light
   */
  light = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    this.light.shadow.camera.zoom = 4;

    const subCameras = [];

    for (let i = 0; i < AMOUNT * AMOUNT; i++) {

      const subCamera = new THREE.PerspectiveCamera(40, 1, 0.1, 10);
      subCamera.viewport = new THREE.Vector4();

      subCameras.push(subCamera);
    }

    this.camera = new THREE.ArrayCamera(subCameras);
    this.camera.position.z = 3;

    this.updateCameras()

    const geometryBackground = new THREE.PlaneGeometry(100, 100);
    const materialBackground = new THREE.MeshPhongMaterial({ color: 0x000066 });

    const background = new THREE.Mesh(geometryBackground, materialBackground);
    background.receiveShadow = true;
    background.position.set(0, 0, - 1);
    core.render.scene.add(background);

    const geometryCylinder = new THREE.CylinderGeometry(0.5, 0.5, 1, 32);
    const materialCylinder = new THREE.MeshPhongMaterial({ color: 0xff0000 });

    this.mesh = new THREE.Mesh(geometryCylinder, materialCylinder);
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;
    core.render.scene.add(this.mesh);

    core.render.render = () => {
      core.render.renderer.render(core.render.scene, this.camera)
    }
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  onResize(core) {
    this.updateCameras()
  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    this.mesh.rotation.x += 0.005;
    this.mesh.rotation.z += 0.01;
  }

  updateCameras() {
    const ASPECT_RATIO = window.innerWidth / window.innerHeight;
    const WIDTH = window.innerWidth / AMOUNT;
    const HEIGHT = window.innerHeight / AMOUNT;

    this.camera.aspect = ASPECT_RATIO;
    this.camera.updateProjectionMatrix();

    for (let y = 0; y < AMOUNT; y++) {

      for (let x = 0; x < AMOUNT; x++) {

        const subcamera = this.camera.cameras[AMOUNT * y + x];
        subcamera.copy(this.camera); // copy fov, aspect ratio, near, far from the root camera

        subcamera.viewport.set(Math.floor(x * WIDTH), Math.floor(y * HEIGHT), Math.ceil(WIDTH), Math.ceil(HEIGHT));
        subcamera.updateProjectionMatrix();

        subcamera.position.x = (x / AMOUNT) - 0.5;
        subcamera.position.y = 0.5 - (y / AMOUNT);
        subcamera.position.z = 1.5 + ((x + y) * .5);
        subcamera.position.multiplyScalar(2);

        subcamera.lookAt(0, 0, 0);
        subcamera.updateMatrixWorld();

      }
    }
  }
}