class Script extends VD.Component {
  /**
   * @serialize
   * @type {THREE.Texture} 
   * @label iceDiffuse
   */
  iceDiffuse = null;

  /**
   * @serialize
   * @type {THREE.Object3D} 
   * @label model
   */
  model = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { time, positionWorld, mx_worley_noise_float, color, screenUV, vec2, viewportLinearDepth, viewportDepthTexture, viewportSharedTexture, linearDepth } = TSL
    const t = time.mul(.8);
    const floorUV = positionWorld.xzy;

    const waterLayer0 = mx_worley_noise_float(floorUV.mul(4).add(t));
    const waterLayer1 = mx_worley_noise_float(floorUV.mul(2).add(t));

    const waterIntensity = waterLayer0.mul(waterLayer1);
    const waterColor = waterIntensity.mul(1.4).mix(color(0x0487e2), color(0x74ccf4));

    // linearDepth() returns the linear depth of the mesh
    const depth = linearDepth();
    const depthWater = viewportLinearDepth.sub(depth).toInspector('Water / Depth', (node) => node.oneMinus());
    const depthEffect = depthWater.remapClamp(-.002, .04);

    const refractionUV = screenUV.add(vec2(0, waterIntensity.mul(.1))).toInspector('Water / Refraction UV');

    // linearDepth( viewportDepthTexture( uv ) ) return the linear depth of the scene
    const depthTestForRefraction = linearDepth(viewportDepthTexture(refractionUV)).sub(depth);

    const depthRefraction = depthTestForRefraction.remapClamp(0, .1);

    const finalUV = depthTestForRefraction.lessThan(0).select(screenUV, refractionUV);

    const viewportTexture = viewportSharedTexture(finalUV).toInspector('Water / Viewport Texture + Refraction UV');

    const waterMaterial = new THREE.MeshBasicNodeMaterial();
    waterMaterial.colorNode = waterColor.toInspector('Water / Color');
    waterMaterial.backdropNode = depthEffect.mix(viewportSharedTexture(), viewportTexture.mul(depthRefraction.mix(1, waterColor)));
    waterMaterial.backdropAlphaNode = depthRefraction.oneMinus();
    waterMaterial.transparent = true;

    const water = new THREE.Mesh(new THREE.BoxGeometry(50, .001, 50), waterMaterial);
    water.position.set(0, 0, 0);
    core.render.scene.add(water);

    this.initIces(water, waterLayer0)

    this.initGUI()

    this.initPostProcessing()
  }

  initIces(water, waterLayer0) {
    const { triplanarTexture, color, texture } = TSL
    const iceColorNode = triplanarTexture(texture(this.iceDiffuse)).add(color(0x0066ff)).mul(.8);

    const geometry = new THREE.IcosahedronGeometry(1, 3);
    const material = new THREE.MeshStandardNodeMaterial({ colorNode: iceColorNode });

    const count = 100;
    const scale = 3.5;
    const column = 10;

    for (let i = 0; i < count; i++) {

      const x = i % column;
      const y = i / column;

      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(x * scale, 0, y * scale);
      mesh.rotation.set(Math.random(), Math.random(), Math.random());
      this.object.add(mesh);
    }

    this.object.position.set(
      ((column - 1) * scale) * - .5,
      - 1,
      ((count / column) * scale) * - .5
    );

    this.initFloor(water, iceColorNode, material, waterLayer0)
  }

  initFloor(water, iceColorNode, material, waterLayer0) {
    const { positionWorld, normalWorld } = TSL
    // floor
    this.floor = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 10), new THREE.MeshStandardNodeMaterial({ colorNode: iceColorNode }));
    this.floor.position.set(0, - 5, 0);
    this.core.render.scene.add(this.floor);

    // caustics

    const waterPosY = positionWorld.y.sub(water.position.y);

    let transition = waterPosY.add(.1).saturate().oneMinus();
    transition = waterPosY.lessThan(0).select(transition, normalWorld.y.mix(transition, 0)).toVar();

    const colorNode = transition.mix(material.colorNode, material.colorNode.add(waterLayer0));

    //material.colorNode = colorNode;
    this.floor.material.colorNode = colorNode;
  }

  initGUI() {
    const gui = this.core.render.renderer.inspector.createParameters('Settings');

    this.floorPosition = new THREE.Vector3(0, .2, 0);

    gui.add(this.floorPosition, 'y', - 1, 1, .001).name('floor position');
  }

  initPostProcessing() {
    const { pass, objectPosition, gaussianBlur, screenUV, color } = TSL
    const { scene, camera } = this.core.render

    const scenePass = pass(scene, camera);
    const scenePassColor = scenePass.getTextureNode();
    const scenePassDepth = scenePass.getLinearDepthNode().remapClamp(.3, .5);

    const waterMask = objectPosition(camera).y.greaterThan(screenUV.y.sub(.5).mul(camera.near)).toInspector('Post-Processing / Water Mask');

    const scenePassColorBlurred = gaussianBlur(scenePassColor);
    scenePassColorBlurred.directionNode = waterMask.select(scenePassDepth, scenePass.getLinearDepthNode().mul(5)).toInspector('Post-Processing / Blur Strength [ Depth ]', (node) => node.toFloat());

    const vignette = screenUV.distance(.5).mul(1.35).clamp().oneMinus().toInspector('Post-Processing / Vignette');

    this.core.render.pipeline.outputNode = waterMask.select(scenePassColorBlurred, scenePassColorBlurred.mul(color(0x74ccf4)).mul(vignette));
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    const delta = core.timer.getDelta();
    const elapsed = core.timer.getElapsed()

    this.floor.position.y = this.floorPosition.y - 5;


    if (this.model) {
      this.model.position.y = this.floorPosition.y;
    }

    for (const object of this.object.children) {

      object.position.y = Math.sin(elapsed + object.id) * .3;
      object.rotation.y += delta * .3;
    }
  }
}