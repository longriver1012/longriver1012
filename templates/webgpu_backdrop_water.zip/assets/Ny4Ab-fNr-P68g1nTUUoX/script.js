class Script extends VD.Component {
  /**
   * @serialize
   * @type {THREE.AnimationClip} 
   * @label clip
   */
  clip = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    this.mixer = new THREE.AnimationMixer(this.object);

    this.action = this.mixer.clipAction(this.clip);

    this.action.play();
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    const delta = core.timer.getDelta()

    this.mixer.update(delta)
  }
}