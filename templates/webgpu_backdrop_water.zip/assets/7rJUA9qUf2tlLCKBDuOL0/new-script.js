class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { normalWorld, color } = TSL
    core.render.scene.backgroundNode = normalWorld.y.mix(color(0x0487e2), color(0x0066ff));
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }
}