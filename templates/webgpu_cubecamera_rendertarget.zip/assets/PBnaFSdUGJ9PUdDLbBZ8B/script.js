
class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    THREE.RectAreaLightNode.setLTC(ADDONS.RectAreaLightTexturesLib.init());

    this.rectarealight = new THREE.RectAreaLight(0xffffff, 2.2, 0.36, 0.6);

    this.rectarealight.position.set(0, 0.4, 0)
    this.rectarealight.rotateX(-Math.PI / 2)

    core.render.scene.add(this.rectarealight)
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {

  }
}