class Script extends VD.Component {
  /**
   * @serialize
   * @type {THREE.Object3D}
   */
  ground = null;

  /**
   * @serialize
   * @type {THREE.Object3D}
   */
  ground2 = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    // this.useCubeCamera()
    this.useReflector()
  }

  useCubeCamera() {
    this.cubeRenderTarget = new THREE.CubeRenderTarget(256)

    this.cubeCamera = new THREE.CubeCamera(0.01, 2, this.cubeRenderTarget)

    this.ground.material.roughnessMap = this.ground.material.roughnessMap.clone()

    this.ground.material.roughnessMap.repeat.set(1, 10)
    this.ground.material.roughnessMap.needsUpdate = true

    this.ground.material.envMap = this.cubeRenderTarget.texture
    this.ground2.material.envMap = this.cubeRenderTarget.texture

    this.useCubeCameraMode = true
  }

  useReflector() {
    const { reflector, mix, color, float, roughness } = TSL;

    // 创建 TSL reflector 节点（WebGPU 专用）
    const reflection1 = reflector();

    reflection1.target.rotateX(-Math.PI / 2);

    this.core.render.scene.add(reflection1.target);

    // 克隆 roughnessMap
    this.ground.material.roughnessMap = this.ground.material.roughnessMap.clone();
    this.ground.material.roughnessMap.repeat.set(1, 10);
    this.ground.material.roughnessMap.needsUpdate = true;

    // 创建节点材质
    const groundMat = new THREE.MeshStandardNodeMaterial();
    groundMat.roughness = 0.15;
    groundMat.roughnessMap = this.ground.material.roughnessMap;
    groundMat.metalness = 0;
    groundMat.color.set(0x666666);
    groundMat.colorNode = mix(color(0x666666), reflection1, float(1.0).sub(roughness).mul(0.5));
    groundMat.envMapIntensity = 0
    this.ground.material = groundMat;

    // ground2 同理
    const reflection2 = reflector();

    reflection2.target.rotateX(-Math.PI / 2);

    this.core.render.scene.add(reflection2.target);

    const ground2Mat = new THREE.MeshStandardNodeMaterial();
    ground2Mat.roughness = 0.15;
    ground2Mat.roughnessMap = this.ground2.material.roughnessMap;
    ground2Mat.metalness = 0;
    ground2Mat.color.set(0x222222);
    ground2Mat.colorNode = mix(color(0x222222), reflection2, float(1.0).sub(roughness).mul(0.5));
    ground2Mat.envMapIntensity = 0
    this.ground2.material = ground2Mat;
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {
    if (!this.useCubeCameraMode) return

    const { camera, scene, renderer } = core.render
    this.cubeCamera.position.set(camera.position.x, -camera.position.y, camera.position.z)

    this.cubeCamera.update(renderer, scene)
  }
}