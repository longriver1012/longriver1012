class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { instancedArray, hash, vec3, If, uv, shapeCircle, uniform, float, Fn, instanceIndex } = TSL

    const particleCount = 200000;

    const gravity = uniform(-0.00098);
    const bounce = uniform(.8);
    const friction = uniform(.99);
    const size = uniform(.12);

    const clickPosition = uniform(new THREE.Vector3());

    const positions = instancedArray(particleCount, 'vec3');
    const velocities = instancedArray(particleCount, 'vec3');
    const colors = instancedArray(particleCount, 'vec3');

    this.clickPosition = clickPosition

    // compute

    const separation = 0.2;
    const amount = Math.sqrt(particleCount);
    const offset = float(amount / 2);

    const computeInit = Fn(() => {

      const position = positions.element(instanceIndex);
      const color = colors.element(instanceIndex);

      const x = instanceIndex.mod(amount);
      const z = instanceIndex.div(amount);

      position.x = offset.sub(x).mul(separation);
      position.z = offset.sub(z).mul(separation);

      color.x = hash(instanceIndex);
      color.y = hash(instanceIndex.add(2));

    })().compute(particleCount).setName('Init Particles');

    const computeUpdate = Fn(() => {

      const position = positions.element(instanceIndex);
      const velocity = velocities.element(instanceIndex);

      velocity.addAssign(vec3(0.00, gravity, 0.00));
      position.addAssign(velocity);

      velocity.mulAssign(friction);

      // floor

      If(position.y.lessThan(0), () => {

        position.y = 0;
        velocity.y = velocity.y.negate().mul(bounce);

        // floor friction

        velocity.x = velocity.x.mul(.9);
        velocity.z = velocity.z.mul(.9);

      });
    });

    this.computeParticles = computeUpdate().compute(particleCount).setName('Update Particles');

    // create particles

    const material = new THREE.SpriteNodeMaterial();
    material.colorNode = uv().mul(colors.element(instanceIndex));
    material.positionNode = positions.toAttribute();
    material.scaleNode = size;
    material.opacityNode = shapeCircle();
    material.alphaToCoverage = true;
    material.transparent = true;

    const particles = new THREE.Sprite(material);
    particles.count = particleCount;
    particles.frustumCulled = false;
    core.render.scene.add(particles);


    const helper = new THREE.GridHelper(90, 45, 0x303030, 0x303030);
    core.render.scene.add(helper);

    const geometry = new THREE.PlaneGeometry(200, 200);
    geometry.rotateX(- Math.PI / 2);

    const plane = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ visible: false }));
    core.render.scene.add(plane);

    this.plane = plane

    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();

    core.render.renderer.compute(computeInit);

    // Hit

    this.computeHit = Fn(() => {

      const position = positions.element(instanceIndex);
      const velocity = velocities.element(instanceIndex);

      const dist = position.distance(clickPosition);
      const direction = position.sub(clickPosition).normalize();
      const distArea = float(3).sub(dist).max(0);

      const power = distArea.mul(.01);
      const relativePower = power.mul(hash(instanceIndex).mul(1.5).add(.5));

      velocity.assign(velocity.add(direction.mul(relativePower)));

    })().compute(particleCount).setName('Hit Particles');

    document.addEventListener('pointermove', this.onMove)

    // gui

    const gui = core.render.renderer.inspector.createParameters('Settings');

    gui.add(gravity, 'value', - .0098, 0, 0.0001).name('gravity');
    gui.add(bounce, 'value', .1, 1, 0.01).name('bounce');
    gui.add(friction, 'value', .96, .99, 0.01).name('friction');
    gui.add(size, 'value', .12, .5, 0.01).name('size');

    const controls = VD.findComponent(this.core.render.camera, (item) => item.constructor.name === "轨道控制器")

    controls.controls.addEventListener('start', () => {
      this.isOrbitControlsActive = true;
    });

    controls.controls.addEventListener('end', () => {
      this.isOrbitControlsActive = false;
    });
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {
    core.render.renderer.compute(this.computeParticles);
  }

  onMove = (event) => {
    if (this.isOrbitControlsActive) return;

    this.pointer.set((event.clientX / window.innerWidth) * 2 - 1, - (event.clientY / window.innerHeight) * 2 + 1);

    this.raycaster.setFromCamera(this.pointer, this.core.render.camera);

    const intersects = this.raycaster.intersectObject(this.plane, false);

    if (intersects.length > 0) {

      const { point } = intersects[0];

      // move to uniform

      this.clickPosition.value.copy(point);
      this.clickPosition.value.y = - 1;

      // compute

      this.core.render.renderer.compute(this.computeHit);
    }
  }
}