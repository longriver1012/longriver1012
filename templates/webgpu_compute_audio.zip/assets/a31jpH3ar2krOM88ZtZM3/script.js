class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    function createTextTexture(text) {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 256;

      const ctx = canvas.getContext('2d');

      // 背景：圆角矩形渐变
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
      gradient.addColorStop(0, "#bf1ae8");
      gradient.addColorStop(1, "#880da1");
      ctx.fillStyle = gradient;
      roundRect(ctx, 0, 0, canvas.width, canvas.height, 32);
      ctx.fill();

      const cx = canvas.width / 2;
      const cy = canvas.height / 2;

      // 文字
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 48px "Microsoft YaHei", "PingFang SC", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, cx + 5, cy);

      const texture = new THREE.CanvasTexture(canvas);
      texture.colorSpace = THREE.SRGBColorSpace
      console.log(texture)
      return texture;

    }

    function roundRect(ctx, x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + w - r, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + r);
      ctx.lineTo(x + w, y + h - r);
      ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      ctx.lineTo(x + r, y + h);
      ctx.quadraticCurveTo(x, y + h, x, y + h - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();

    }

    // 创建带纹理的平面
    const texture = createTextTexture('播放音频');

    this.object.material.map = texture
    this.object.material.needsUpdate = true
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }

  onClick = () => {
    this.object.visible = false

    const component = VD.findComponent(this.object, (item) => item.constructor.name === 'script.js')

    document.addEventListener('click', component.playAudioBuffer);
  }
}