class Script extends VD.Component {
  /**
   * @serialize
   * @type {AudioBuffer} 
   */
  audioBuffer = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { instancedArray, uniform, instanceIndex, float, Fn, screenUV, color, texture } = TSL

    this.waveBuffer = this.audioBuffer.getChannelData(0);

    // adding extra silence to delay and pitch
    this.waveBuffer = new Float32Array([...this.waveBuffer, ...new Float32Array(200000)]);

    this.sampleRate = this.audioBuffer.sampleRate / this.audioBuffer.numberOfChannels;

    // create webgpu buffers

    this.waveArray = instancedArray(this.waveBuffer);

    // read-only buffer

    const originalWave = instancedArray(this.waveBuffer).toReadOnly();

    // The Pixel Buffer Object (PBO) is required to get the GPU computed data to the CPU in the WebGL2 fallback.
    // As used in `renderer.getArrayBufferAsync( waveArray.value )`.
    originalWave.setPBO(true);
    this.waveArray.setPBO(true);

    // params
    const pitch = uniform(1.5);
    const delayVolume = uniform(.2);
    const delayOffset = uniform(.55);

    // compute (shader-node)
    const computeShaderFn = Fn(() => {
      const index = float(instanceIndex);
      // pitch
      const time = index.mul(pitch);

      let wave = originalWave.element(time);

      // delay
      for (let i = 1; i < 7; i++) {
        const waveOffset = originalWave.element(index.sub(delayOffset.mul(this.sampleRate).mul(i)).mul(pitch));
        const waveOffsetVolume = waveOffset.mul(delayVolume.div(i * i));

        wave = wave.add(waveOffsetVolume);
      }

      // store
      const waveStorageElementNode = this.waveArray.element(instanceIndex);

      waveStorageElementNode.assign(wave);
    });

    // compute
    this.computeNode = computeShaderFn().compute(this.waveBuffer.length);

    // nodes
    this.analyserBuffer = new Uint8Array(1024);

    this.analyserTexture = new THREE.DataTexture(this.analyserBuffer, this.analyserBuffer.length, 1, THREE.RedFormat);

    const spectrum = texture(this.analyserTexture, screenUV.x).x.mul(screenUV.y);
    const backgroundNode = color(0x0000FF).mul(spectrum);

    core.render.scene.backgroundNode = backgroundNode

    const gui = core.render.renderer.inspector.createParameters('Audio');

    gui.add(pitch, 'value', .5, 2, 0.01).name('pitch');
    gui.add(delayVolume, 'value', 0, 1, .01).name('delayVolume');
    gui.add(delayOffset, 'value', .1, 1, .01).name('delayOffset');
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    if (this.currentAnalyser) {
      this.currentAnalyser.getByteFrequencyData(this.analyserBuffer);

      this.analyserTexture.needsUpdate = true;
    }
  }

  playAudioBuffer = async () => {
    if (this.currentAudio) this.currentAudio.stop();

    // compute audio

    this.core.render.renderer.compute(this.computeNode);

    const wave = new Float32Array(await this.core.render.renderer.getArrayBufferAsync(this.waveArray.value));

    // play result

    const audioOutputContext = new AudioContext({ sampleRate: this.sampleRate });
    const audioOutputBuffer = audioOutputContext.createBuffer(1, wave.length, this.sampleRate);

    audioOutputBuffer.copyToChannel(wave, 0);

    const source = audioOutputContext.createBufferSource();
    source.connect(audioOutputContext.destination);
    source.buffer = audioOutputBuffer;
    source.start();

    this.currentAudio = source;

    // visual feedback

    this.currentAnalyser = audioOutputContext.createAnalyser();
    this.currentAnalyser.fftSize = 2048;

    source.connect(this.currentAnalyser);
  }
}