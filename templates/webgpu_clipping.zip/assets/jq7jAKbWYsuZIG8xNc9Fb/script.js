class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { scene } = core.render
    // Clipping planes

    const globalPlane = new THREE.Plane(new THREE.Vector3(- 1, 0, 0), 0.1);
    const localPlane1 = new THREE.Plane(new THREE.Vector3(0, - 1, 0), 0.8);
    const localPlane2 = new THREE.Plane(new THREE.Vector3(0, 0, - 1), 0.1);

    // Clipping Groups

    const globalClippingGroup = new THREE.ClippingGroup();
    globalClippingGroup.clippingPlanes = [globalPlane];

    const knotClippingGroup = new THREE.ClippingGroup();
    knotClippingGroup.clippingPlanes = [localPlane1, localPlane2];
    knotClippingGroup.clipIntersection = true;

    scene.add(globalClippingGroup);
    globalClippingGroup.add(knotClippingGroup);

    // Geometry

    const material = new THREE.MeshPhongNodeMaterial({
      color: 0x80ee10,
      shininess: 0,
      side: THREE.DoubleSide,

      // ***** Clipping setup (material): *****
      alphaToCoverage: true
    });

    const geometry = new THREE.TorusKnotGeometry(0.4, 0.08, 95, 20);

    this.target = new THREE.Mesh(geometry, material);
    this.target.castShadow = true;
    knotClippingGroup.add(this.target);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(9, 9, 1, 1),
      new THREE.MeshPhongNodeMaterial({ color: 0xa0adaf, shininess: 150, alphaToCoverage: true })
    );

    ground.rotation.x = - Math.PI / 2; // rotates X/Y to X/Z
    ground.receiveShadow = true;
    globalClippingGroup.add(ground);

    const gui = core.render.renderer.inspector.createParameters('Clipping settings');
    const props = {
      alphaToCoverage: true,
    };

    const folderKnot = gui.addFolder('Knot Clipping Group');
    const propsKnot = {

      get 'Enabled'() {

        return knotClippingGroup.enabled;

      },
      set 'Enabled'(v) {

        knotClippingGroup.enabled = v;

      },

      get 'Shadows'() {

        return knotClippingGroup.clipShadows;

      },
      set 'Shadows'(v) {

        knotClippingGroup.clipShadows = v;

      },

      get 'Intersection'() {

        return knotClippingGroup.clipIntersection;

      },

      set 'Intersection'(v) {

        knotClippingGroup.clipIntersection = v;

      },

      get 'Plane'() {

        return localPlane1.constant;

      },
      set 'Plane'(v) {

        localPlane1.constant = v;

      }

    };

    const folderGlobal = gui.addFolder('Global Clipping Group');
    const propsGlobal = {

      get 'Enabled'() {

        return globalClippingGroup.enabled;

      },
      set 'Enabled'(v) {

        globalClippingGroup.enabled = v;

      },

      get 'Plane'() {

        return globalPlane.constant;

      },
      set 'Plane'(v) {

        globalPlane.constant = v;

      }

    };

    gui.add(props, 'alphaToCoverage').onChange(function (value) {

      ground.material.alphaToCoverage = value;
      ground.material.needsUpdate = true;

      material.alphaToCoverage = value;
      material.needsUpdate = true;

    });

    folderKnot.add(propsKnot, 'Enabled');
    folderKnot.add(propsKnot, 'Shadows');
    folderKnot.add(propsKnot, 'Intersection');
    folderKnot.add(propsKnot, 'Plane', 0.3, 1.25);

    folderGlobal.add(propsGlobal, 'Enabled');
    folderGlobal.add(propsGlobal, 'Plane', - 0.4, 3);
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    const elapsed = core.timer.getElapsed()

    this.target.position.y = 0.8;
    this.target.rotation.x = elapsed * 0.5;
    this.target.rotation.y = elapsed * 0.2;
    this.target.scale.setScalar(Math.cos(elapsed) * 0.125 + 0.875);
  }
}