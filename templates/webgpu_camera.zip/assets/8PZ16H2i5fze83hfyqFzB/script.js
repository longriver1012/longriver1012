let SCREEN_WIDTH = window.innerWidth;
let SCREEN_HEIGHT = window.innerHeight;
let aspect = SCREEN_WIDTH / SCREEN_HEIGHT;
let frustumSize = 600;

class Script extends VD.Component {
  /**
 * @serialize
 * @type {THREE.Object3D} 
 * @label cameraRig
 */
  cameraRig = null;
  /**
   * @serialize
   * @type {THREE.Object3D} 
   * @label cameraPerspective
   */
  cameraPerspective = null;

  /**
   * @serialize
   * @type {THREE.Object3D} 
   * @label cameraOrtho
   */
  cameraOrtho = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { scene, camera } = core.render

    camera.aspect = 0.5 * aspect
    camera.updateProjectionMatrix()

    this.cameraPerspectiveHelper = new THREE.CameraHelper(this.cameraPerspective);

    scene.add(this.cameraPerspectiveHelper);

    this.cameraOrtho.left = 0.5 * frustumSize * aspect / - 2
    this.cameraOrtho.right = 0.5 * frustumSize * aspect / 2
    this.cameraOrtho.top = frustumSize / 2
    this.cameraOrtho.bottom = frustumSize / - 2
    this.cameraOrtho.updateProjectionMatrix()

    this.cameraOrthoHelper = new THREE.CameraHelper(this.cameraOrtho);

    scene.add(this.cameraOrthoHelper);

    this.activeCamera = this.cameraPerspective;
    this.activeHelper = this.cameraPerspectiveHelper;

    this.mesh = new THREE.Mesh(
      new THREE.SphereGeometry(100, 16, 8),
      new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true })
    );
    scene.add(this.mesh);

    const mesh2 = new THREE.Mesh(
      new THREE.SphereGeometry(50, 16, 8),
      new THREE.MeshBasicMaterial({ color: 0x00ff00, wireframe: true })
    );
    mesh2.position.y = 150;
    this.mesh.add(mesh2);

    const mesh3 = new THREE.Mesh(
      new THREE.SphereGeometry(5, 16, 8),
      new THREE.MeshBasicMaterial({ color: 0x0000ff, wireframe: true })
    );
    mesh3.position.z = 150;
    this.cameraRig.add(mesh3);

    //

    const geometry = new THREE.BufferGeometry();
    const vertices = [];

    for (let i = 0; i < 10000; i++) {

      vertices.push(THREE.MathUtils.randFloatSpread(2000)); // x
      vertices.push(THREE.MathUtils.randFloatSpread(2000)); // y
      vertices.push(THREE.MathUtils.randFloatSpread(2000)); // z

    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));

    const particles = new THREE.Points(geometry, new THREE.PointsMaterial({ color: 0xffffff }));
    scene.add(particles);

    this.renderer = core.render.renderer
    this.scene = scene
    this.camera = camera
    core.render.render = this.render

    document.addEventListener('keydown', this.onKeyDown);

    this.onResize(core)
  }

  onKeyDown = (event) => {
    switch (event.keyCode) {
      case 79: /*O*/
        this.activeCamera = this.cameraOrtho;
        this.activeHelper = this.cameraOrthoHelper;

        break;

      case 80: /*P*/
        this.activeCamera = this.cameraPerspective;
        this.activeHelper = this.cameraPerspectiveHelper;
        break;
    }

  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }

  render = () => {
    const r = Date.now() * 0.0005;

    const { activeCamera, cameraPerspective, cameraPerspectiveHelper, cameraOrthoHelper,
      mesh, cameraRig, activeHelper, renderer, scene, camera, cameraOrtho } = this

    mesh.position.x = 700 * Math.cos(r);
    mesh.position.z = 700 * Math.sin(r);
    mesh.position.y = 700 * Math.sin(r);

    mesh.children[0].position.x = 70 * Math.cos(2 * r);
    mesh.children[0].position.z = 70 * Math.sin(r);

    if (activeCamera === cameraPerspective) {

      cameraPerspective.fov = 35 + 30 * Math.sin(0.5 * r);
      cameraPerspective.far = mesh.position.length();
      cameraPerspective.updateProjectionMatrix();

      cameraPerspectiveHelper.update();
      cameraPerspectiveHelper.visible = true;

      cameraOrthoHelper.visible = false;

    } else {

      cameraOrtho.far = mesh.position.length();
      cameraOrtho.updateProjectionMatrix();

      cameraOrthoHelper.update();
      cameraOrthoHelper.visible = true;

      cameraPerspectiveHelper.visible = false;
    }

    cameraRig.lookAt(mesh.position);

    //

    activeHelper.visible = false;

    renderer.setClearColor(0x000000, 1);
    renderer.setScissor(0, 0, SCREEN_WIDTH / 2, SCREEN_HEIGHT);
    renderer.setViewport(0, 0, SCREEN_WIDTH / 2, SCREEN_HEIGHT);
    renderer.render(scene, activeCamera);

    //

    activeHelper.visible = true;

    renderer.setClearColor(0x111111, 1);
    renderer.setScissor(SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2, SCREEN_HEIGHT);
    renderer.setViewport(SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2, SCREEN_HEIGHT);
    renderer.render(scene, camera);
  }

  onResize(core) {
    SCREEN_WIDTH = window.innerWidth;
    SCREEN_HEIGHT = window.innerHeight;
    aspect = SCREEN_WIDTH / SCREEN_HEIGHT;

    this.renderer.setSize(SCREEN_WIDTH, SCREEN_HEIGHT);

    requestAnimationFrame(() => {
      this.camera.aspect = 0.5 * aspect;
      this.camera.updateProjectionMatrix();
    })

    this.cameraPerspective.aspect = 0.5 * aspect;
    this.cameraPerspective.updateProjectionMatrix();

    this.cameraOrtho.left = - 0.5 * frustumSize * aspect / 2;
    this.cameraOrtho.right = 0.5 * frustumSize * aspect / 2;
    this.cameraOrtho.top = frustumSize / 2;
    this.cameraOrtho.bottom = - frustumSize / 2;
    this.cameraOrtho.updateProjectionMatrix();

    console.log(this.camera)
  }
}