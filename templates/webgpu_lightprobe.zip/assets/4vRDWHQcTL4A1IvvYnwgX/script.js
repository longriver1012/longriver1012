class Script extends VD.Component {
  /**
   * @serialize
   * @type {THREE.Texture}
   */
  hdr = null

  /**
   * @serialize
   * @type {THREE.Object3D}
   */
  directionalLight = null

  /**
   * @serialize
   * @type {THREE.Material}
   */
  material = null

  /** 
   * @param {VD.Core} core
   */
  async onMount(core) {
    const API = {
      lightProbeIntensity: 0.16,
      directionalLightIntensity: this.directionalLight.intensity,
      envMapIntensity: core.render.scene.environmentIntensity
    };

    // 将等距柱状投影 HDR 转换为真正的 CubeRenderTarget（6 面）
    const cubeRenderTarget = new THREE.CubeRenderTarget(256);
    cubeRenderTarget.fromEquirectangularTexture(core.render.renderer, this.hdr);

    // 从 CubeRenderTarget 生成光照探针
    const probe = await ADDONS.LightProbeGenerator.fromCubeRenderTarget(core.render.renderer, cubeRenderTarget);

    // light probe
    this.lightProbe = new THREE.LightProbe();
    this.lightProbe.copy(probe);
    this.lightProbe.intensity = API.lightProbeIntensity;

    core.render.scene.add(this.lightProbe);

    cubeRenderTarget.dispose();

    // material 
    this.material.envMap = this.hdr
    this.material.envMapIntensity = API.envMapIntensity

    // gui
    const gui = core.render.renderer.inspector.createParameters('Settings')

    gui.add(API, 'lightProbeIntensity', 0, 1, 0.02)
      .name('light probe')
      .onChange(() => {
        this.lightProbe.intensity = API.lightProbeIntensity;
      });

    gui.add(API, 'directionalLightIntensity', 0, 1, 0.02)
      .name('directional light')
      .onChange(() => {
        this.directionalLight.intensity = API.directionalLightIntensity;
      });

    gui.add(API, 'envMapIntensity', 0, 1, 0.02)
      .name('envMap')
      .onChange(() => {
        this.material.envMapIntensity = API.envMapIntensity
        // core.render.scene.environmentIntensity = API.envMapIntensity;
      });
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {

  }
}