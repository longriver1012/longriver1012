
class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const {
      Fn, float, vec2, vec3, vec4,
      uniform, positionWorld,
      mix, abs, fract, floor, clamp, smoothstep, length, max,
      dFdx, dFdy, fwidth
    } = TSL

    const u_majorLineColor = uniform(new THREE.Color(0x444444));
    const u_minorLineColor = uniform(new THREE.Color(0x888888));
    const u_bgColor = uniform(new THREE.Color(0xffffff));
    const u_dotColor = uniform(new THREE.Color(0x222222));

    const u_majorLineWidth = uniform(0.01);
    const u_minorLineWidth = uniform(0.01);
    const u_gridScale = uniform(1.0);
    const u_majorGridDiv = uniform(10.0);
    const u_dotRadius = uniform(0.04);
    const u_scrollOffset = uniform(new THREE.Vector2(0, 0));
    const u_fadeStart = uniform(10.0);
    const u_fadeEnd = uniform(30.0);

    // ---- pristineGrid ----

    const pristineGrid = Fn(([uv_immutable, lineWidth]) => {

      const uv = uv_immutable.toVar();
      const uvDDXY = vec4(dFdx(uv), dFdy(uv));
      const uvDeriv = vec2(length(uvDDXY.xz), length(uvDDXY.yw));

      const invertLine = lineWidth.greaterThan(0.5);
      const targetWidth = invertLine.select(float(1.0).sub(lineWidth), lineWidth);

      const drawWidth = clamp(vec2(targetWidth), uvDeriv, vec2(0.5));
      const lineAA = uvDeriv.mul(1.5);

      let gridUV = abs(fract(uv).mul(2.0).sub(1.0));
      gridUV = invertLine.select(gridUV, float(1.0).sub(gridUV));

      let grid2 = smoothstep(drawWidth.add(lineAA), drawWidth.sub(lineAA), gridUV);
      grid2 = grid2.mul(clamp(vec2(targetWidth, targetWidth).div(drawWidth), float(0.0), float(1.0)));
      grid2 = mix(grid2, vec2(targetWidth, targetWidth), clamp(uvDeriv.mul(2.0).sub(1.0), float(0.0), float(1.0)));
      grid2 = invertLine.select(vec2(1.0).sub(grid2), grid2);

      return mix(grid2.x, float(1.0), grid2.y);
    });

    // ---- gridDots ----

    const gridDots = Fn(([uv_immutable, radius]) => {

      const uv = uv_immutable.toVar();
      const uvDeriv = fwidth(uv);
      const nearest = fract(uv.add(0.5)).sub(0.5);
      const dist = length(nearest);
      const drawRadius = max(radius, length(uvDeriv).mul(0.5));
      const aa = length(uvDeriv);
      let dot = smoothstep(drawRadius.add(aa), drawRadius, dist);
      dot = dot.mul(clamp(radius.div(drawRadius), float(0.0), float(1.0)));

      return dot;

    });

    // ---- gridColorNode ----

    const gridColorNode = Fn(() => {

      // 使用世界坐标的 xz 平面
      const vWorldPos = positionWorld.xz;

      const majorDiv = max(float(2.0), floor(u_majorGridDiv.add(0.5)));
      const gridCoord = vWorldPos.add(u_scrollOffset).mul(u_gridScale);

      const minorGrid = pristineGrid(gridCoord, u_minorLineWidth);
      const majorGrid = pristineGrid(gridCoord.div(majorDiv), u_majorLineWidth);
      const majorDots = gridDots(gridCoord.div(majorDiv), u_dotRadius);

      // 颜色混合
      let color = u_bgColor.toVec3().toVar();
      color.assign(mix(color, u_minorLineColor.toVec3(), minorGrid));
      color.assign(mix(color, u_majorLineColor.toVec3(), majorGrid));
      color.assign(mix(color, u_dotColor.toVec3(), majorDots));

      // 距离淡出
      const dist = length(vWorldPos);
      const alpha = float(1.0).sub(smoothstep(u_fadeStart, u_fadeEnd, dist));

      return vec4(color, alpha);

    })();

    const gridMaterial = new THREE.MeshPhongNodeMaterial({
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
      shininess: 0
    });
    gridMaterial.colorNode = gridColorNode;

    this.object.material = gridMaterial
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {

  }
}