class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const {
      Fn,
      vec2,
      vec3,
      vec4,
      float,
      int,
      uniform,
      uniformArray,
      positionLocal,    // 如果环境支持 positionGeometry 优先使用
      normalView,
      positionViewDirection,
      time,
      Loop,
      If,
      Discard,
      abs,
      acos,
      clamp,
      dot,
      floor,
      fract,
      max,
      min,
      mix,
      normalize,
      pow,
      sin,
      smoothstep,
      step,
      select,
      screenUV,
      color,
      uv
    } = TSL;

    const MAX_HITS = 6;

    const shieldUniforms = {
      uColor: uniform(new THREE.Color("#26aeff")),
      uLife: uniform(1.0),
      uHexScale: uniform(1.0),
      uEdgeWidth: uniform(0.06),
      uFresnelPower: uniform(1.8),
      uFresnelStrength: uniform(1.75),
      uOpacity: uniform(0.76),
      // ★ 关键修复：0.0 = 完全可见, 1.0 = 完全隐藏
      uReveal: uniform(0.0),
      uFlashSpeed: uniform(0.6),
      uFlashIntensity: uniform(0.11),
      uNoiseScale: uniform(1.3),
      uNoiseEdgeColor: uniform(new THREE.Color("#26aeff")),
      uNoiseEdgeWidth: uniform(0.02),
      uNoiseEdgeIntensity: uniform(10.0),
      uNoiseEdgeSmoothness: uniform(0.5),
      uHexOpacity: uniform(0.13),
      uShowHex: uniform(1.0),
      uFlowScale: uniform(2.4),
      uFlowSpeed: uniform(1.13),
      uFlowIntensity: uniform(4.0),
      uHitRingSpeed: uniform(1.75),
      uHitRingWidth: uniform(0.12),
      uHitMaxRadius: uniform(0.85),
      uHitDuration: uniform(1.8),
      uHitIntensity: uniform(4.1),
      uHitImpactRadius: uniform(0.30),
      uFadeStart: uniform(0.0),
      uHitPos: uniformArray(
        Array.from({ length: MAX_HITS }, () => new THREE.Vector3(0, 1.8, 0)),
        "vec3"
      ),
      uHitTime: uniformArray(
        new Array(MAX_HITS).fill(-999),
        "float"
      ),
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Simplex 3D Noise
    // ══════════════════════════════════════════════════════════════════════════

    const mod289v3 = Fn(([x_immutable]) => {
      const x = vec3(x_immutable).toVar();
      return x.sub(floor(x.mul(1.0 / 289.0)).mul(289.0));
    });

    const mod289v4 = Fn(([x_immutable]) => {
      const x = vec4(x_immutable).toVar();
      return x.sub(floor(x.mul(1.0 / 289.0)).mul(289.0));
    });

    const permute = Fn(([x_immutable]) => {
      const x = vec4(x_immutable).toVar();
      return mod289v4(x.mul(34.0).add(1.0).mul(x));
    });

    const taylorInvSqrt = Fn(([r_immutable]) => {
      const r = vec4(r_immutable).toVar();
      return float(1.79284291400159).sub(r.mul(0.85373472095314));
    });

    const snoise = Fn(([v_immutable]) => {
      const v = vec3(v_immutable).toVar();

      const C = vec2(1.0 / 6.0, 1.0 / 3.0);
      const D = vec4(0.0, 0.5, 1.0, 2.0);

      const i = floor(v.add(dot(v, C.yyy))).toVar();
      const x0 = v.sub(i).add(dot(i, C.xxx)).toVar();

      const g = step(x0.yzx, x0.xyz).toVar();
      const l = float(1.0).sub(g).toVar();
      const i1 = min(g.xyz, l.zxy).toVar();
      const i2 = max(g.xyz, l.zxy).toVar();

      const x1 = x0.sub(i1).add(C.xxx).toVar();
      const x2 = x0.sub(i2).add(C.yyy).toVar();
      const x3 = x0.sub(D.yyy).toVar();

      i.assign(mod289v3(i));

      const p = permute(
        permute(
          permute(
            i.z.add(vec4(0.0, i1.z, i2.z, 1.0))
          ).add(i.y).add(vec4(0.0, i1.y, i2.y, 1.0))
        ).add(i.x).add(vec4(0.0, i1.x, i2.x, 1.0))
      ).toVar();

      const n_ = float(0.142857142857);
      const ns = n_.mul(D.wyz).sub(D.xzx).toVar();

      const j = p.sub(floor(p.mul(ns.z).mul(ns.z)).mul(49.0)).toVar();
      const x_ = floor(j.mul(ns.z)).toVar();
      const y_ = floor(j.sub(x_.mul(7.0))).toVar();

      const x = x_.mul(ns.x).add(ns.yyyy).toVar();
      const y = y_.mul(ns.x).add(ns.yyyy).toVar();
      const h = float(1.0).sub(abs(x)).sub(abs(y)).toVar();

      const b0 = vec4(x.xy, y.xy).toVar();
      const b1 = vec4(x.zw, y.zw).toVar();

      const s0 = floor(b0).mul(2.0).add(1.0).toVar();
      const s1 = floor(b1).mul(2.0).add(1.0).toVar();
      const sh = step(h, vec4(0.0)).negate().toVar();

      const a0 = b0.xzyw.add(s0.xzyw.mul(sh.xxyy)).toVar();
      const a1 = b1.xzyw.add(s1.xzyw.mul(sh.zzww)).toVar();

      const p0 = vec3(a0.xy, h.x).toVar();
      const p1 = vec3(a0.zw, h.y).toVar();
      const p2 = vec3(a1.xy, h.z).toVar();
      const p3 = vec3(a1.zw, h.w).toVar();

      const norm = taylorInvSqrt(
        vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3))
      ).toVar();

      p0.mulAssign(norm.x);
      p1.mulAssign(norm.y);
      p2.mulAssign(norm.z);
      p3.mulAssign(norm.w);

      const m = max(
        float(0.6).sub(vec4(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3))),
        0.0
      ).toVar();
      m.assign(m.mul(m));

      return float(42.0).mul(
        dot(m.mul(m), vec4(dot(p0, x0), dot(p1, x1), dot(p2, x2), dot(p3, x3)))
      );
    });

    // ══════════════════════════════════════════════════════════════════════════
    // Helper functions
    // ══════════════════════════════════════════════════════════════════════════

    const lifeColor = Fn(([life_immutable]) => {
      const life = float(life_immutable).toVar();
      return mix(vec3(1.0, 0.08, 0.04), shieldUniforms.uColor, life);
    });

    const squarePattern = Fn(([p_immutable]) => {
      const p = vec2(p_immutable).toVar();
      p.mulAssign(shieldUniforms.uHexScale);

      const s = vec2(1.0, 2);

      // ★ 修复：显式构造 vec4 避免 vec4(vec2, vec2) 兼容性问题
      const hC = floor(
        vec2(p.x, p.y).div(vec2(s.x, s.y))
      ).add(0.5).toVar(); // Math.floor(-0.5) = -1

      const h_val = vec2(
        p.x.sub(hC.x.mul(s.x)),
        p.y.sub(hC.y.mul(s.y)),
      ).toVar();

      const cell = h_val.xy.toVar();

      const absCell = abs(cell).toVar();
      const d = max( cell.y).toVar();

      return smoothstep(float(0.5).sub(shieldUniforms.uEdgeWidth), float(0.5), d);
    })

    const hexPattern = Fn(([p_immutable]) => {
      const p = vec2(p_immutable).toVar();
      p.mulAssign(shieldUniforms.uHexScale);

      const s = vec2(1.0, 1.7320508);

      // ★ 修复：显式构造 vec4 避免 vec4(vec2, vec2) 兼容性问题
      const hC = floor(
        vec4(p.x, p.y, p.x.sub(0.5), p.y.sub(1.0)).div(vec4(s.x, s.y, s.x, s.y))
      ).add(0.5).toVar();

      const h_val = vec4(
        p.x.sub(hC.x.mul(s.x)),
        p.y.sub(hC.y.mul(s.y)),
        p.x.sub(hC.z.add(0.5).mul(s.x)),
        p.y.sub(hC.w.add(0.5).mul(s.y))
      ).toVar();

      const cell = select(
        dot(h_val.xy, h_val.xy).lessThan(dot(h_val.zw, h_val.zw)),
        h_val.xy,
        h_val.zw
      ).toVar();

      const absCell = abs(cell).toVar();
      const d = max(dot(absCell, s.mul(0.5)), absCell.x).toVar();

      return smoothstep(float(0.5).sub(shieldUniforms.uEdgeWidth), float(0.5), d);
    });

    const hexCellId = Fn(([p_immutable]) => {
      const p = vec2(p_immutable).toVar();
      p.mulAssign(shieldUniforms.uHexScale);

      const s = vec2(1.0, 1.7320508);
      const hC = floor(
        vec4(p.x, p.y, p.x.sub(0.5), p.y.sub(1.0)).div(vec4(s.x, s.y, s.x, s.y))
      ).add(0.5).toVar();

      const h_val = vec4(
        p.x.sub(hC.x.mul(s.x)),
        p.y.sub(hC.y.mul(s.y)),
        p.x.sub(hC.z.add(0.5).mul(s.x)),
        p.y.sub(hC.w.add(0.5).mul(s.y))
      ).toVar();

      return select(
        dot(h_val.xy, h_val.xy).lessThan(dot(h_val.zw, h_val.zw)),
        hC.xy,
        hC.zw.add(0.5)
      );
    });

    const cellFlash = Fn(([cellId_immutable]) => {
      const cellId = vec2(cellId_immutable).toVar();
      const rnd = fract(sin(dot(cellId, vec2(127.1, 311.7))).mul(43758.5453)).toVar();
      const phase = rnd.mul(6.2831).toVar();
      const speed = float(0.5).add(rnd.mul(1.5)).toVar();

      return smoothstep(
        float(0.6),
        float(1.0),
        sin(time.mul(shieldUniforms.uFlashSpeed).mul(speed).add(phase))
      ).mul(shieldUniforms.uFlashIntensity);
    });

    const shieldFragment = Fn(() => {
      const objPos = positionLocal.toVar();
      const vNormal = normalView.toVar();
      const vViewDir = positionViewDirection.toVar();

      const noise = snoise(objPos.mul(shieldUniforms.uNoiseScale)).mul(0.5).add(0.5).toVar();
      const revealMask = smoothstep(
        shieldUniforms.uReveal.sub(shieldUniforms.uNoiseEdgeWidth),
        shieldUniforms.uReveal,
        noise
      ).toVar();

      If(revealMask.lessThan(0.001), () => {
        Discard();
      });

      const innerFade = mix(float(0.98), float(0.15), shieldUniforms.uNoiseEdgeSmoothness).toVar();
      const edgeLow = smoothstep(
        shieldUniforms.uReveal.sub(shieldUniforms.uNoiseEdgeWidth), // x - 0.02
        shieldUniforms.uReveal.sub(shieldUniforms.uNoiseEdgeWidth.mul(innerFade)), // x - 0.01
        noise
      ).toVar();
      const edgeHigh = smoothstep(
        shieldUniforms.uReveal.sub(shieldUniforms.uNoiseEdgeWidth.mul(0.15)), // x - 0.003
        shieldUniforms.uReveal, // x - 0
        noise
      ).toVar();
      const revealEdge = edgeLow.mul(float(1.0).sub(edgeHigh)).toVar(); // edgeLow * (1.0 - edgeHigh)

      // ── 2. Fresnel ───────────────────────────────────────────────────────
      const fresnel = pow(
        float(1.0).sub(dot(vNormal, vViewDir)),
        shieldUniforms.uFresnelPower
      ).mul(shieldUniforms.uFresnelStrength).toVar();

      // ── 3. Flow noise ────────────────────────────────────────────────────
      const t = time.mul(shieldUniforms.uFlowSpeed).toVar();
      const fn1 = snoise(
        objPos.mul(shieldUniforms.uFlowScale).add(vec3(t, t.mul(0.6), t.mul(0.4)))
      ).toVar();
      const fn2 = snoise(
        objPos.mul(shieldUniforms.uFlowScale).mul(2.1).add(
          vec3(t.negate().mul(0.5), t.mul(0.9), t.mul(0.3))
        )
      ).toVar();
      const flowNoise = fn1.mul(0.6).add(fn2.mul(0.4)).mul(0.5).add(0.5).toVar();

      // ── 4. Hex grid ──────────────────────────────────────────────────────
      const absN = abs(normalize(objPos)).toVar();
      const dominance = max(absN.x, max(absN.y, absN.z)).toVar();
      const hexFade = smoothstep(float(0.65), float(0.85), dominance).toVar();

      // const faceUV = select(
      //   absN.x.greaterThanEqual(absN.y).and(absN.x.greaterThanEqual(absN.z)),
      //   objPos.yz,
      //   select(
      //     absN.y.greaterThanEqual(absN.z),
      //     objPos.xz,
      //     objPos.xy
      //   )
      // ).toVar();

      const faceUV = objPos.xy.toVar()

      const hex = squarePattern(faceUV).mul(hexFade).toVar();
      // const hex = hexPattern(uv()).mul(hexFade).toVar();
      const cId = hexCellId(faceUV).toVar();
      const flash = cellFlash(cId).mul(hexFade).toVar();

      // ── 6. Combine ───────────────────────────────────────────────────────
      const lColor = lifeColor(shieldUniforms.uLife).toVar();

      // const effectiveHexOpacity = shieldUniforms.uHexOpacity
      //   .add(hexHitBoost.mul(shieldUniforms.uHitIntensity))
      //   .mul(shieldUniforms.uShowHex)
      //   .toVar();

      // const intensity = hex.mul(effectiveHexOpacity)
      //   .mul(float(0.3).add(fresnel.mul(0.7)))
      //   .add(fresnel.mul(0.4))
      //   .add(flash.mul(shieldUniforms.uShowHex))
      //   .toVar();

      const edgeColor = mix(
        shieldUniforms.uNoiseEdgeColor,
        lColor,
        float(1.0).sub(shieldUniforms.uLife)
      ).toVar();
      const edgeGlow = edgeColor.mul(revealEdge).mul(shieldUniforms.uNoiseEdgeIntensity).toVar();

      // const alpha = clamp(
      //   intensity.mul(shieldUniforms.uOpacity).mul(revealMask)
      //     .add(revealEdge.mul(shieldUniforms.uNoiseEdgeIntensity)),
      //   0.0,
      //   1.0
      // ).toVar();

      return vec4(hex, hex, hex, 1.0)
      // return vec4(edgeGlow, alpha)
      // return vec4(noise, noise, noise, 1.0)
    })

    const material = new THREE.NodeMaterial();
    material.fragmentNode = shieldFragment();
    material.transparent = true;
    material.depthWrite = false;
    material.side = THREE.FrontSide;
    material.blending = THREE.AdditiveBlending;

    this.object.material = material

    const gui = core.render.renderer.inspector.createParameters('Settings');
    gui.add(shieldUniforms.uReveal, 'value', 0.0, 1.0, 0.01).name('reveal')
    gui.add(shieldUniforms.uNoiseEdgeIntensity, 'value', 0.0, 100.0, 0.1).name('uNoiseEdgeIntensity')

    // 背景色
    const horizontalEffect = screenUV.x.mix(color(0x13172b), color(0x311649));
    const lightEffect = screenUV.distance(vec2(0.5, 1.0)).oneMinus().mul(color(0x0c5d68));

    core.render.scene.backgroundNode = horizontalEffect.add(lightEffect);
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {

  }
}