class Script extends VD.Component {
  /**
   * @serialize
   * @type {THREE.Object3D}
   * @label 模型
   */
  model = null;

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { uniform, normalView, max, Fn, vec4, float, dot, positionViewDirection } = TSL

    const uRimColor = uniform(new THREE.Color('#18bcdc'));
    const uRimPower = uniform(3.0);
    const uRimIntensity = uniform(1.5);
    const uBaseColor = uniform(new THREE.Color(0.0, 0.0, 0.0));

    const colorNode = Fn(() => {
      const vNormal = normalView.toVar();
      const vViewDir = positionViewDirection.toVar();

      const fresnel = float(1.0).sub(max(dot(vNormal, vViewDir), 0.0)).pow(uRimPower).mul(uRimIntensity);;

      const finalColor = uBaseColor.add(uRimColor.mul(fresnel));

      return vec4(finalColor, 1.0)
    })

    const material = new THREE.NodeMaterial()

    material.colorNode = colorNode()

    this.model.material = material

    const gui = core.render.renderer.inspector.createParameters('Setting');

    gui.addColor(uRimColor, 'value').name('uRimColor');
    gui.addColor(uBaseColor, 'value').name('uBaseColor');
    gui.add(uRimPower, 'value').name('uRimPower');
    gui.add(uRimIntensity, 'value').name('uRimIntensity');
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onUpdate(core) {

  }
}