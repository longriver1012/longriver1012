class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { float, hue, viewportSharedTexture, oscSine, grayscale, saturation, blendOverlay, viewportSafeUV, screenUV, color, vec3, checker, uv } = TSL

    const geometry = new THREE.SphereGeometry(.3, 32, 16);

    const addBackdropSphere = (backdropNode, backdropAlphaNode = null) => {
      const distance = 1;
      const id = this.object.children.length;
      const rotation = THREE.MathUtils.degToRad(id * 45);

      const material = new THREE.MeshStandardNodeMaterial({ color: 0x0066ff });
      material.roughnessNode = float(.2);
      material.metalnessNode = float(0);
      material.backdropNode = backdropNode;
      material.backdropAlphaNode = backdropAlphaNode;
      material.transparent = true;

      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(
        Math.cos(rotation) * distance,
        1,
        Math.sin(rotation) * distance
      );

      this.object.add(mesh);
    }

    addBackdropSphere(hue(viewportSharedTexture().bgr, oscSine().mul(Math.PI)));
    addBackdropSphere(viewportSharedTexture().rgb.oneMinus());
    addBackdropSphere(grayscale(viewportSharedTexture().rgb));
    addBackdropSphere(saturation(viewportSharedTexture().rgb, 10), oscSine());
    addBackdropSphere(blendOverlay(viewportSharedTexture().rgb, checker(uv().mul(10))));
    addBackdropSphere(viewportSharedTexture(viewportSafeUV(screenUV.mul(40).floor().div(40))));
    addBackdropSphere(viewportSharedTexture(viewportSafeUV(screenUV.mul(80).floor().div(80))).add(color(0x0033ff)));
    addBackdropSphere(vec3(0, 0, viewportSharedTexture().b));
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    const delta = core.timer.getDelta()
    
    this.object.rotation.y += delta * 0.5;
  }
}