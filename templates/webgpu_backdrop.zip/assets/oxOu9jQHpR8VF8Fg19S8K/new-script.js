class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { oscSine, output, time, posterize } = TSL

    this.mixer = new THREE.AnimationMixer(this.object);

    const material = this.object.children[0].children[0].material;
    material.outputNode = oscSine(time.mul(.1)).mix(output, posterize(output.add(.1), 4).mul(2));

    const action = this.mixer.clipAction(this.object.animations[0]);
    action.play();
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {
    const delta = core.timer.getDelta()
    
    this.mixer.update(delta)
  }
}