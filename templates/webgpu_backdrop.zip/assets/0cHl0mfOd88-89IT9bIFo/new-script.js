class Script extends VD.Component {
  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    this.object.power = 2000
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {
    
  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }
}