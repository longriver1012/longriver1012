class Script extends VD.Component {

  /** 
   * @param {VD.Core} core
   */
  onMount(core) {
    const { screenUV, color } = TSL

    core.render.scene.backgroundNode = screenUV.y.mix(color(0x66bbff), color(0x4466ff));
  }

  /**
   * @param {VD.Core} core
   */
  onUnmount(core) {

  }

  /**
   * @param {VD.Core} core
   */
  onRenderBefore(core) {

  }
}